package org.javalite.db_migrator;

public enum DatabaseType {
    MYSQL, POSTGRESQL, SQL_SERVER, HSQL, H2, DB2, ORACLE, UNKNOWN
}
