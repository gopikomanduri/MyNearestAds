mvn clean install -Pmysql,instrument -DargLine="-Dactivejdbc.log"
