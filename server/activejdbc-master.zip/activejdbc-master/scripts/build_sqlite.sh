mvn clean install -Psqlite,instrument -DargLine="-Dactivejdbc.log"
