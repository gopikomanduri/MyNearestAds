# need Java 6 for this 

mvn clean javadoc:aggregate
