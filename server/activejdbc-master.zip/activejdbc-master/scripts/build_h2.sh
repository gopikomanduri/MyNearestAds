mvn clean install -Ph2,instrument -DargLine="-Dactivejdbc.log"
