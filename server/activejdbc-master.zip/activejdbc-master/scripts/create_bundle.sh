mvn  clean  source:jar javadoc:jar package gpg:sign repository:bundle-create
