mvn clean install -Ptds,instrument -DargLine="-Dactivejdbc.log"

