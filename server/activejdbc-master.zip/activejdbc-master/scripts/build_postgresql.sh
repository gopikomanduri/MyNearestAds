mvn clean install -Ppostgresql,instrument -DargLine="-Dactivejdbc.log"
