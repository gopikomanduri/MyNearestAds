package org.javalite.activejdbc.test_models;

import org.javalite.activejdbc.Model;

/**
 * @author Igor Polevoy: 7/11/12 9:57 AM
 */
public class Image extends Model {

}
