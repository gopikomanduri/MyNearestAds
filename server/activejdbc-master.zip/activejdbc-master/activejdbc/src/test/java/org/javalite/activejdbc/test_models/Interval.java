package org.javalite.activejdbc.test_models;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.Table;

/**
 * @author Igor Polevoy on 1/1/16.
 */

@Table("`interval`")
public class Interval extends Model{
}
