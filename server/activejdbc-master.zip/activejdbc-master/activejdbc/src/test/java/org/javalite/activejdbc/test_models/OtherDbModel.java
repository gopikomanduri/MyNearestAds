package org.javalite.activejdbc.test_models;

import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.DbName;

/**
 * @author Igor Polevoy: 4/23/12 12:08 PM
 */
@DbName("test")
public class OtherDbModel extends Model {
}
