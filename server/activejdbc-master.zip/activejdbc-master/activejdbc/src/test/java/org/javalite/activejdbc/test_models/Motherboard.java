package org.javalite.activejdbc.test_models;

import org.javalite.activejdbc.Model;

public class Motherboard extends Model {

}
