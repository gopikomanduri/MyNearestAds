package org.javalite.activejdbc.test_models;

import org.javalite.activejdbc.Model;

/**
 * @author Igor Polevoy: 11/11/12 8:45 PM
 */
public class Apple extends Model {
}
