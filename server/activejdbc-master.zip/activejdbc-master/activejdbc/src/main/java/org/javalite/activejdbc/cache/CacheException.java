package org.javalite.activejdbc.cache;

/**
 * @author Igor Polevoy on 12/9/15.
 */
public class CacheException extends RuntimeException {
    public CacheException(String message, Throwable cause) {
        super(message, cause);
    }
}
