mvn -o compile process-test-classes -Pinstrument
