## Integration test

for [JavaLite DB-Migrator](https://github.com/javalite/activejdbc/tree/master/db-migrator)
