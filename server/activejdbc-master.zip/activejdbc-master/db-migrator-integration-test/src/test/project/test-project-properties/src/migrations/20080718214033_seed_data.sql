INSERT INTO books VALUES (1, '112345678901', hello('Book A'), null, weighted_average(5,9,2,1));
INSERT INTO books VALUES (2, '112345678902', hello('Book B'), null, weighted_average(7,7,7,5));
INSERT INTO books VALUES (3, '112345678903', hello('Book C'), null, weighted_average(6,3,7,8));
INSERT INTO books VALUES (4, '112345678904', hello('Book D'), null, weighted_average(2,2,0,4));
INSERT INTO books VALUES (5, '112345678905', hello('Book E'), null, weighted_average(8,4,7,8));
INSERT INTO books VALUES (6, '112345678906', hello('Book F'), null, weighted_average(0,4,5,1));
INSERT INTO books VALUES (7, '112345678907', hello('Book G'), null, weighted_average(1,5,7,2));
INSERT INTO books VALUES (8, '112345678908', hello('Book H'), null, weighted_average(3,4,3,3));
INSERT INTO books VALUES (9, '112345678909', hello('Book I'), null, weighted_average(8,3,7,1));

INSERT INTO authors VALUES (1, 'Jonathon', 'Carrol');
INSERT INTO authors VALUES (2, 'David', 'Eggers');