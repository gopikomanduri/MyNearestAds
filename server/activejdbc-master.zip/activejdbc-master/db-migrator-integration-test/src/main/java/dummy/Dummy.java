package dummy;

/**
 * @author Igor Polevoy on 6/17/15.
 */
public class Dummy {
//    Trying to make gpg plugin happy. Do not delete this class.
}
